@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto missing
py -3 install_database.py
if errorlevel 1 goto failed
pause
exit /b 0
:missing
echo Python Launcher was not found. Install Python 3.12 first.
pause
exit /b 1
:failed
echo Import failed. Read the message above. Existing data was not intentionally replaced on failure.
pause
exit /b 1

"""Merge converted recipes into existing application data; application code is untouched."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import tempfile
import uuid


def read_library(path):
    value=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(value,list) or any(not isinstance(r,dict) or not isinstance(r.get('name'),str) or not isinstance(r.get('ingredients'),list) for r in value):
        raise ValueError(f'Invalid recipe library: {path}. Nothing was overwritten.')
    return value


def merge(existing,incoming):
    result=list(existing)
    sources={r.get('source_url') for r in result if r.get('source_url')}
    names={r['name'].strip().casefold() for r in result}
    added=0
    for recipe in incoming:
        source=recipe.get('source_url','')
        if source and source in sources:
            continue
        if not source and recipe['name'].strip().casefold() in names:
            continue
        recipe=dict(recipe)
        base=recipe['name'];n=2
        while recipe['name'].strip().casefold() in names:
            recipe['name']=f'{base} ({n})';n+=1
        names.add(recipe['name'].strip().casefold())
        if source:sources.add(source)
        result.append(recipe);added+=1
    return result,added


def install(source,target):
    source,target=Path(source),Path(target)
    if source.resolve()==target.resolve():
        raise ValueError('Source and destination must be different files.')
    incoming=read_library(source)
    original=target.read_bytes() if target.exists() else None
    existing=read_library(target) if original is not None else []
    merged,added=merge(existing,incoming)
    if not added:
        print(f'No new recipes. Existing: {len(existing)}.')
        return 0,None
    target.parent.mkdir(parents=True,exist_ok=True)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=target.parent,delete=False) as handle:
            temporary=Path(handle.name)
            json.dump(merged,handle,ensure_ascii=False,separators=(',',':'),allow_nan=False)
        current=target.read_bytes() if target.exists() else None
        if current!=original:
            raise ValueError('The library changed during import. Close the application and retry. Nothing was overwritten.')
        backup=None
        if original is not None:
            backup=target.with_name('recipes.before-import-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]+'.json')
            with backup.open('xb') as handle:handle.write(original)
        temporary.replace(target)
        print(f'Added: {added}. Total: {len(merged)}.')
        print(f'Library: {target}')
        if backup:print(f'Backup: {backup}')
        return added,backup
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=Path(__file__).with_name('recipes.json'))
    parser.add_argument('--target',type=Path)
    args=parser.parse_args()
    target=args.target
    if target is None:
        location=os.environ.get('LOCALAPPDATA')
        if not location:
            parser.error('LOCALAPPDATA is not set. On Windows run as your usual user, or provide --target.')
        target=Path(location)/'NJ-cooking'/'recipes.json'
    print('Close NJ-Cooking before importing. Application source files will not be modified.')
    try:
        install(args.source,target)
    except (ValueError,OSError) as exc:
        print('Import failed:',exc)
        return 1
    print('Done. Open NJ-Cooking. Imported recipes need review before menu generation.')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
